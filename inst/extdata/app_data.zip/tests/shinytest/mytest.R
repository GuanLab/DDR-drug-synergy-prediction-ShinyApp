app <- ShinyDriver$new("../../")
app$snapshotInit("mytest")

app$snapshot()
